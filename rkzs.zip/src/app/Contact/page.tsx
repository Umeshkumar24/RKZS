'use client'
import { Mac } from "@/components/Mac";
import Join from "@/components/Join";
import { motion } from "framer-motion"
import { AuroraBackground } from "@/components/ui/aurora-background";

export default function Home() {
  return (
    <>
      
    </>
  );
}
