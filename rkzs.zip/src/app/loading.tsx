import Load2 from "@/components/Load2";

export default function loading() {
  return (
    <>
      {/* <h1>Loading....</h1> */}
      <center>
      <Load2 />
      </center>
    </>
  )
}
